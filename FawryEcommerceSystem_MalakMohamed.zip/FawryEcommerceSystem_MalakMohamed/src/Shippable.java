public interface Shippable {
    String getName();
    double getWeight();
}
